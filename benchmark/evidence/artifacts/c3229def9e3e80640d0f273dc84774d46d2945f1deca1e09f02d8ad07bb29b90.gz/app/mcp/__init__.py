"""Model Context Protocol integration."""
