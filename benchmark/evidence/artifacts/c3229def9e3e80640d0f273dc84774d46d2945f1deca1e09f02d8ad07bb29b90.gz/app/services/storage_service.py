"""Scoped, atomic local job storage."""

from __future__ import annotations

import asyncio
import hashlib
import inspect
import json
import os
import re
import shutil
import tempfile
import zipfile
from collections.abc import AsyncIterable, AsyncIterator
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Literal

from app.models.content_result import ContentAsset
from app.models.parse_result import DocumentParseResult
from app.models.source import StoredSource
from app.security.file_validation import FileValidationError, safe_filename, validate_stored_file
from app.utils.settings import setting, setting_path

_SAFE_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$")


@dataclass(frozen=True, slots=True)
class StoredResultPaths:
    result: Path
    warnings: Path


class AssetIndexError(ValueError):
    """Persisted asset metadata does not use the current index contract."""


class StorageService:
    def __init__(self, settings: object | None = None) -> None:
        self.settings = settings
        self.data_dir = setting_path(settings, "data_dir", "data").resolve()
        self.jobs_dir = self.data_dir / "jobs"
        self.max_upload_bytes = int(setting(settings, "max_upload_bytes", 200 * 1024 * 1024))
        self.max_content_units = int(setting(settings, "max_content_units", 1_000))
        self.max_video_seconds = int(setting(settings, "max_video_seconds", 30 * 60))
        self.max_video_frame_pixels = int(
            setting(settings, "video_max_frame_pixels", 7680 * 4320)
        )

    async def initialize(self) -> None:
        await asyncio.to_thread(self.jobs_dir.mkdir, parents=True, exist_ok=True)

    @staticmethod
    def _validate_job_id(job_id: str) -> str:
        if not _SAFE_ID_RE.fullmatch(job_id):
            raise ValueError("invalid job identifier")
        return job_id

    def job_dir(self, job_id: str) -> Path:
        return self.jobs_dir / self._validate_job_id(job_id)

    def input_dir(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "input"

    def output_dir(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "output"

    def logs_dir(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "logs"

    def assets_dir(self, job_id: str) -> Path:
        return self.job_dir(job_id) / "assets"

    def original_assets_dir(self, job_id: str) -> Path:
        return self.assets_dir(job_id) / "original"

    def derived_assets_dir(self, job_id: str) -> Path:
        return self.assets_dir(job_id) / "derived"

    def keyframes_dir(self, job_id: str) -> Path:
        return self.derived_assets_dir(job_id) / "keyframes"

    def previews_dir(self, job_id: str) -> Path:
        return self.derived_assets_dir(job_id) / "previews"

    async def create_job_layout(self, job_id: str) -> Path:
        root = self.job_dir(job_id)

        def create() -> None:
            jobs_root = self.jobs_dir.resolve()
            resolved = root.resolve(strict=False)
            if resolved.parent != jobs_root or root.is_symlink():
                raise OSError("job storage path escapes the configured jobs directory")
            root.mkdir(parents=True, exist_ok=True)
            for directory in (
                self.input_dir(job_id),
                self.output_dir(job_id),
                self.logs_dir(job_id),
                self.original_assets_dir(job_id),
                self.keyframes_dir(job_id),
                self.previews_dir(job_id),
            ):
                if directory.is_symlink():
                    raise OSError("job storage subdirectory must not be a symbolic link")
                directory.mkdir(parents=True, exist_ok=True)

        await asyncio.to_thread(create)
        return root

    async def _iter_stream(
        self, stream: object, chunk_size: int = 1024 * 1024
    ) -> AsyncIterator[bytes]:
        while True:
            result = stream.read(chunk_size)  # type: ignore[attr-defined]
            chunk = await result if inspect.isawaitable(result) else result
            if not chunk:
                break
            if not isinstance(chunk, (bytes, bytearray, memoryview)):
                raise TypeError("binary source stream returned non-bytes data")
            yield bytes(chunk)

    async def save_stream(
        self,
        job_id: str,
        filename: str,
        stream: BinaryIO | object,
        *,
        source_url: str | None = None,
    ) -> StoredSource:
        return await self.save_chunks(
            job_id, filename, self._iter_stream(stream), source_url=source_url
        )

    async def save_bytes(
        self,
        job_id: str,
        filename: str,
        content: bytes,
        *,
        source_url: str | None = None,
    ) -> StoredSource:
        async def chunks() -> AsyncIterator[bytes]:
            yield content

        return await self.save_chunks(job_id, filename, chunks(), source_url=source_url)

    async def save_chunks(
        self,
        job_id: str,
        filename: str,
        chunks: AsyncIterable[bytes],
        *,
        source_url: str | None = None,
    ) -> StoredSource:
        await self.create_job_layout(job_id)
        input_dir = self.input_dir(job_id)
        temporary = input_dir / ".upload.part"
        total = 0
        try:
            with temporary.open("wb") as handle:
                async for chunk in chunks:
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > self.max_upload_bytes:
                        raise FileValidationError(
                            "file_too_large",
                            f"file exceeds maximum size of {self.max_upload_bytes} bytes",
                        )
                    await asyncio.to_thread(handle.write, chunk)
                await asyncio.to_thread(handle.flush)
                await asyncio.to_thread(os.fsync, handle.fileno())

            cleaned, mime_type, size, page_count = await asyncio.to_thread(
                validate_stored_file,
                temporary,
                filename,
                max_bytes=self.max_upload_bytes,
                max_pages=self.max_content_units,
                max_video_seconds=self.max_video_seconds,
                max_video_frame_pixels=self.max_video_frame_pixels,
            )
            target = input_dir / safe_filename(cleaned)
            if target.exists():
                target = input_dir / f"original{target.suffix}"
            await asyncio.to_thread(os.replace, temporary, target)
            return StoredSource(
                path=target,
                filename=cleaned,
                mime_type=mime_type,
                size_bytes=size,
                page_count=page_count,
                source_url=source_url,
            )
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise

    @staticmethod
    def _atomic_write(path: Path, data: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(
            prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
        )
        temporary = Path(temporary_name)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise

    async def write_result(self, job_id: str, result: DocumentParseResult) -> StoredResultPaths:
        await self.create_job_layout(job_id)
        output = self.output_dir(job_id)
        if result.parse_result is None:
            raise ValueError("internal parse result is required before persistence")
        paths = StoredResultPaths(
            result=output / "result.md",
            warnings=self.logs_dir(job_id) / "warnings.json",
        )
        asset_index = output / "asset-index.json"
        warning_payload = {
            "document_warnings": [warning.model_dump(mode="json") for warning in result.warnings],
            "units": [
                {
                    "unit_index": page.page_number,
                    "status": page.status.value,
                    "warnings": [warning.model_dump(mode="json") for warning in page.warnings],
                }
                for page in result.pages
                if page.warnings
            ],
        }
        await asyncio.gather(
            asyncio.to_thread(self._atomic_write, paths.result, result.markdown.encode("utf-8")),
            asyncio.to_thread(
                self._atomic_write,
                asset_index,
                json.dumps(
                    {
                        "schema": "mosaic-asset-index/2.0",
                        "content_id": result.parse_result.source.content_id,
                        "source_sha256": result.parse_result.source.source_sha256,
                        "assets": [
                            asset.model_dump(mode="json", exclude={"locations"})
                            for asset in result.parse_result.assets
                        ],
                    },
                    ensure_ascii=False,
                    indent=2,
                ).encode("utf-8"),
            ),
            asyncio.to_thread(
                self._atomic_write,
                paths.warnings,
                json.dumps(warning_payload, ensure_ascii=False, indent=2).encode("utf-8"),
            ),
        )
        return paths

    async def write_asset(
        self,
        job_id: str,
        asset_id: str,
        filename: str,
        content: bytes,
        *,
        derived: bool = False,
        derived_category: Literal["keyframes", "previews"] = "keyframes",
    ) -> Path:
        """Persist an addressable asset below the job boundary."""

        self._validate_job_id(asset_id)
        await self.create_job_layout(job_id)
        if derived:
            directory = (
                self.keyframes_dir(job_id)
                if derived_category == "keyframes"
                else self.previews_dir(job_id)
            )
        else:
            directory = self.original_assets_dir(job_id)
        target = directory / f"{asset_id}__{safe_filename(filename)}"
        await asyncio.to_thread(self._atomic_write, target, content)
        return target

    async def copy_asset(
        self,
        job_id: str,
        asset_id: str,
        filename: str,
        source: Path,
        *,
        derived: bool = False,
        derived_category: Literal["keyframes", "previews"] = "keyframes",
    ) -> Path:
        return await self.write_asset(
            job_id,
            asset_id,
            filename,
            await asyncio.to_thread(source.read_bytes),
            derived=derived,
            derived_category=derived_category,
        )

    def asset_path(self, job_id: str, asset_id: str) -> Path | None:
        self._validate_job_id(asset_id)
        root = self.assets_dir(job_id).resolve(strict=False)
        matches = list(root.glob(f"**/{asset_id}__*")) if root.is_dir() else []
        if len(matches) != 1 or not matches[0].is_file() or matches[0].is_symlink():
            return None
        candidate = matches[0].resolve()
        if root not in candidate.parents:
            raise ValueError("asset storage path escapes the configured job directory")
        return candidate

    async def build_bundle(self, job_id: str) -> Path:
        """Atomically create and cache a ZIP bundle for a completed result."""

        index = await self.read_asset_index(job_id)
        raw_assets = index["assets"]
        if not isinstance(raw_assets, list):
            raise AssetIndexError(job_id)
        assets = [ContentAsset.model_validate(item) for item in raw_assets]
        output = self.output_dir(job_id)
        target = output / "assets.zip"
        if target.is_file():
            try:
                with zipfile.ZipFile(target) as archive:
                    cached_manifest = json.loads(archive.read("manifest.json"))
                cached_assets = (
                    cached_manifest.get("assets", []) if isinstance(cached_manifest, dict) else []
                )
                if (
                    isinstance(cached_manifest, dict)
                    and cached_manifest.get("schema") == "mosaic-asset-bundle/1.0"
                    and isinstance(cached_assets, list)
                    and all(
                        isinstance(asset, dict) and "locations" not in asset
                        for asset in cached_assets
                    )
                ):
                    return target
            except (OSError, KeyError, json.JSONDecodeError, zipfile.BadZipFile):
                pass

        def build() -> Path:
            descriptor, temporary_name = tempfile.mkstemp(
                prefix=".assets.", suffix=".zip.tmp", dir=output
            )
            os.close(descriptor)
            temporary = Path(temporary_name)
            try:
                manifest = {
                    "schema": "mosaic-asset-bundle/1.0",
                    "content_id": index["content_id"],
                    "source_sha256": index["source_sha256"],
                    "assets": [
                        asset.model_dump(mode="json", exclude={"locations"}) for asset in assets
                    ],
                }
                with zipfile.ZipFile(
                    temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6
                ) as archive:
                    archive.writestr(
                        "manifest.json",
                        json.dumps(manifest, ensure_ascii=False, indent=2),
                    )
                    for asset in assets:
                        path = self.asset_path(job_id, asset.asset_id)
                        if path is None:
                            continue
                        data = path.read_bytes()
                        if hashlib.sha256(data).hexdigest() != asset.sha256:
                            raise OSError(f"asset checksum mismatch: {asset.asset_id}")
                        archive.writestr(f"assets/{asset.asset_id}/{asset.filename}", data)
                os.replace(temporary, target)
                return target
            except BaseException:
                temporary.unlink(missing_ok=True)
                raise

        return await asyncio.to_thread(build)

    def result_path(self, job_id: str) -> Path | None:
        path = self.output_dir(job_id) / "result.md"
        return path if path.is_file() else None

    async def read_result(self, job_id: str) -> str:
        path = self.result_path(job_id)
        if path is None:
            raise FileNotFoundError(job_id)
        return await asyncio.to_thread(path.read_text, encoding="utf-8")

    async def read_asset_index(self, job_id: str) -> dict[str, object]:
        path = self.output_dir(job_id) / "asset-index.json"
        if not path.is_file():
            raise FileNotFoundError(job_id)
        data = await asyncio.to_thread(path.read_text, encoding="utf-8")
        try:
            payload = json.loads(data)
        except json.JSONDecodeError as exc:
            raise AssetIndexError(job_id) from exc
        if (
            not isinstance(payload, dict)
            or payload.get("schema") != "mosaic-asset-index/2.0"
            or not isinstance(payload.get("assets"), list)
        ):
            raise AssetIndexError(job_id)
        return payload

    async def read_assets(self, job_id: str) -> list[ContentAsset]:
        payload = await self.read_asset_index(job_id)
        raw_assets = payload["assets"]
        if not isinstance(raw_assets, list):
            raise AssetIndexError(job_id)
        return [ContentAsset.model_validate(item) for item in raw_assets]

    async def copy_source(self, source: StoredSource, target_job_id: str) -> StoredSource:
        async def chunks() -> AsyncIterator[bytes]:
            with source.path.open("rb") as handle:
                while chunk := await asyncio.to_thread(handle.read, 1024 * 1024):
                    yield chunk

        return await self.save_chunks(
            target_job_id,
            source.filename,
            chunks(),
            source_url=source.source_url,
        )

    async def delete_job(self, job_id: str) -> bool:
        root = self.job_dir(job_id)
        if not root.exists():
            return False
        if root.is_symlink():
            await asyncio.to_thread(root.unlink)
        else:
            await asyncio.to_thread(shutil.rmtree, root)
        return True

    async def is_writable(self) -> bool:
        try:
            await self.initialize()

            def probe() -> bool:
                descriptor, name = tempfile.mkstemp(prefix=".write-probe-", dir=self.data_dir)
                os.close(descriptor)
                Path(name).unlink()
                return True

            return await asyncio.to_thread(probe)
        except OSError:
            return False
