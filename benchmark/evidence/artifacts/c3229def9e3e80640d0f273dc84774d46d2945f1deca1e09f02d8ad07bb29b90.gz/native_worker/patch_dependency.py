"""Apply and verify the reviewed patch to exactly the supported dependency.

Run during image construction, before starting the worker. A different upstream
source fails the build so a package upgrade cannot silently skip this fix.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import importlib.util
import subprocess
from pathlib import Path

ORIGINAL_SHA256 = "02a4e5bd0564acce4e18ce9b8a9e459c43bc3342ab93bd952db16dabee726fec"
PATCHED_SHA256 = "616f44e2a1749f4b82074df36c3da852694a9401828c6c36aad62553b2a182cf"
PATCH_NAME = "native-text-matching-axis-v1"


def source_path() -> Path:
    spec = importlib.util.find_spec("mineru")
    if spec is None or spec.origin is None:
        raise RuntimeError("MinerU is not installed")
    return Path(spec.origin).parent / "backend/analysis/pdf/text/native.py"


def verify_patch() -> dict[str, str]:
    if importlib.metadata.version("mineru") != "4.0.12":
        raise RuntimeError("the reviewed text-axis patch requires MinerU 4.0.12")
    digest = hashlib.sha256(source_path().read_bytes()).hexdigest()
    if digest != PATCHED_SHA256:
        raise RuntimeError("MinerU native text matching source is unpatched or changed")
    return {"name": PATCH_NAME, "source_sha256": digest}


def main() -> None:
    path = source_path()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest == PATCHED_SHA256:
        verify_patch()
        return
    if importlib.metadata.version("mineru") != "4.0.12" or digest != ORIGINAL_SHA256:
        raise RuntimeError("refusing to patch an unreviewed MinerU version/source")
    patch = Path(__file__).parent / "patches/mineru-4.0.12-text-axis.patch"
    subprocess.run(
        [
            "patch",
            "--batch",
            "--fuzz=0",
            "-p1",
            "-d",
            str(path.parents[5]),
            "-i",
            str(patch.resolve()),
        ],
        check=True,
    )
    print(verify_patch())


if __name__ == "__main__":
    main()
